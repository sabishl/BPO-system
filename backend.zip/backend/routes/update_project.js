const express = require('express');
const { updateProjectStatus } = require('../controllers/projectUpdateController');
const router=express.Router();



module.exports=router;
