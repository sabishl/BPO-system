const express=require('express');
const app=express();
const dotenv=require('dotenv');
const path=require('path');
const cors=require('cors');
const connectDatabase=require('./config/connectDatabase');
dotenv.config({path:path.join(__dirname,'config','config.env')});


const projects=require('./routes/project');
const project_requests=require('./routes/project_request');
const project_update=require('./routes/update_project');
const create_user=require('./routes/create_user');
const login=require('./routes/login');

connectDatabase();

app.use(express.json());
app.use(cors());
app.use('/api/v1/',projects);
app.use('/api/v1/',project_requests);
app.use('/api/v1/',project_update);
app.use('/api/v1/',create_user);
app.use('/api/v1/',login);

app.listen(process.env.PORT,()=>{
   console.log(`Server listening to ${process.env.PORT}  in ${process.env.NODE_ENV}`)
});