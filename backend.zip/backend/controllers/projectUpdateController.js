const UpdateProjectModel = require('../models/projectModel');

exports.addEmployee = async (req, res, next) => {
    try {
        const { emp_email } = req.body; 
        const project = await UpdateProjectModel.findById(req.params.id);
        if (!project) {
            return res.status(404).json({
                success: false,
                message: 'No project found with that ID'
            });
        }

        project.employees.push({ emp_email });

        await project.save();

        res.json({
            success: true,
            message: 'New employee added to the project',
            project
        });
    } catch (error) {
        console.error('Error adding new employee:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};







exports.updateProjectStatus = async (req, res, next) => {
    try {
        const { new_project_status } = req.body; 
        const updatedProject = await UpdateProjectModel.findByIdAndUpdate(
            req.params.id,
            { $set: { project_status: new_project_status } },
            { new: true } 
        );

        if (!updatedProject) {
            return res.status(404).json({
                success: false,
                message: 'No project found with that ID'
            });
        }

        res.json({
            success: true,
            updatedProject
        });
    } catch (error) {
        console.error('Error updating project status:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};

