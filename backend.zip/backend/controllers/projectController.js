const ProjectModel=require('../models/projectModel');

exports.getProjects=async(req,res,next)=>{
   try{
    const projects=await ProjectModel.find({status: 'pending'});
    res.json({
        success:true,
        projects
    })
  }
  catch(error)
    {
     res.status(404).json({
        success:false,
        message:'Unable to get a project with status'
     })   
    }
};

exports.getOngoingProjects=async(req,res,next)=>{
    try{
     const ongoing_projects=await ProjectModel.find({status: 'accepted'});
     res.json({
         success:true,
         ongoing_projects
     })
   }
   catch(error)
     {
      res.status(404).json({
         success:false,
         message:'Unable to get a project with status'
      })   
     }
 };

 exports.getCompletedProjects=async(req,res,next)=>{
    try{
     const completed_projects=await ProjectModel.find({status: 'completed'});
     res.json({
         success:true,
         completed_projects
     })
   }
   catch(error)
     {
      res.status(404).json({
         success:false,
         message:'Unable to get a project with status'
      })   
     }
 };

exports.getSingleProject = async (req, res, next) => {
    try {
        const project = await ProjectModel.findById(req.params.id );
        if (!project) {
            return res.status(404).json({
                success: false,
                message: 'Unable to get a project with that id'
            });
        }
        res.json({
            success: true,
            project
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
}

exports.getProjectsWithEmail=async(req,res,next)=>{
    try{
     const your_projects=await ProjectModel.find({status:"accepted"});
     res.json({
         success:true,
         your_projects
     })
   }
   catch(error)
     {
      res.status(404).json({
         success:false,
         message:'Unable to get a project with email'
      })   
     }
 };