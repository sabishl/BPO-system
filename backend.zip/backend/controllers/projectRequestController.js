const NewProjectModel=require('../models/projectModel');

exports.createProjectRequest = async (req, res, next) => {
    try {
       const {name,description,status,project_status,client_name,client_email,employees}=req.body;

        const newProjects = await NewProjectModel.create({
            name: name,
            description: description,
            status: status,
            project_status: project_status,
            client_name: client_name,
            client_email: client_email,
            employees: employees
        });


        res.json({
            success: true,
            newProjects
        });
    } catch (error) {
        console.error('Error creating project request:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};


exports.updateStatus = async (req, res, next) => {
    try {
        const { new_status } = req.body; 
        const updatedProject = await NewProjectModel.findByIdAndUpdate(
            req.params.id,
            { $set: { status: new_status } },
            { new: true } 
        );

        if (!updatedProject) {
            return res.status(404).json({
                success: false,
                message: 'No project found with that ID'
            });
        }

        res.json({
            success: true,
            updatedProject
        });
    } catch (error) {
        console.error('Error updating project status:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error'
        });
    }
};