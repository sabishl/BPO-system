const mongoose=require('mongoose');

const projectSchema=new mongoose.Schema({
    name:String,
    description:String,
    status:String,
    project_status:String,
    client_name:String,
    client_email:String,
    employees:[
        {
            emp_email:String,
        }
    ],
});

const projectModel=mongoose.model('Project',projectSchema);

module.exports=projectModel;