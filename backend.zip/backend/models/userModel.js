const mongoose=require('mongoose');

const projectSchema=new mongoose.Schema({
    name:String,
    email:String,
    userType:String,
    password:String
});

const userModel=mongoose.model('UserDetails',projectSchema);

module.exports=userModel;